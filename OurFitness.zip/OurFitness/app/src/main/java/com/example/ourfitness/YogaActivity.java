package com.example.ourfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class YogaActivity extends AppCompatActivity {


    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yoga);

        newArray = new int[]{
                R.id.easy_pose, R.id.childs_pose,
                R.id.cat_cow_pose, R.id.downward_dog,
                R.id.standing_forward_bend, R.id.reclining_bound,
                R.id.butt_bridge,R.id.cobra_pose,
                R.id.legs_up_the_wall


        };
    }

    public void Ubimage_onclicked(View view)
    {
        for (int i=0; i<newArray.length; i++)
        {
            if(view.getId() == newArray[i])
            {
                int value = i+1;
                Log.i("First",String.valueOf(value));
                Intent intent = new Intent(YogaActivity.this,Yoga_time_view.class);
                intent.putExtra("value",String.valueOf(value));
                startActivity(intent);
            }
        }
    }

    public void backto_fitness(View view){
        Intent intent = new Intent(YogaActivity.this,FitnessActivity.class);
        startActivity(intent);
    }
}