package com.example.ourfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Fbactivity extends AppCompatActivity {

    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fb);


        newArray = new int[]{
                R.id.lunges_pose, R.id.cat_cow_pose,
                R.id.lunge_twist_pose, R.id.jumping_jacks,
                R.id.round_strech_pose, R.id.push_ups,
                R.id.knee_push_up_pose


        };
    }

    public void image_onclicked(View view)
    {
        for (int i=0; i<newArray.length; i++)
        {
            if(view.getId() == newArray[i])
            {
                int value = i+1;
                Log.i("First",String.valueOf(value));
                Intent intent = new Intent(Fbactivity.this,Exe_Oclock_view.class);
                intent.putExtra("value",String.valueOf(value));
                startActivity(intent);
            }
        }
    }

    public void backto_fitness(View view){
        Intent intent = new Intent(Fbactivity.this,FitnessActivity.class);
        startActivity(intent);
    }

}