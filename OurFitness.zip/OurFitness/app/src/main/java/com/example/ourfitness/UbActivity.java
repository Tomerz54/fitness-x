package com.example.ourfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class UbActivity extends AppCompatActivity {


    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ub);

        newArray = new int[]{
                R.id.back_extension, R.id.good_morning_strech,
                R.id.t_press, R.id.superman_strech,
                R.id.push_ups, R.id.plank_shoulder_taps,
                R.id.shoulder_press,R.id.lateral_raises,
                R.id.staggered_arm_push_ups, R.id.bicep_curls,
                R.id.dumbell_bent_over_row,R.id.tricep_dips,
                R.id.tricep_kickbacks


        };
    }

    public void Ubimage_onclicked(View view)
    {
        for (int i=0; i<newArray.length; i++)
        {
            if(view.getId() == newArray[i])
            {
                int value = i+1;
                Log.i("First",String.valueOf(value));
                Intent intent = new Intent(UbActivity.this,Ub_time_view.class);
                intent.putExtra("value",String.valueOf(value));
                startActivity(intent);
            }
        }
    }

    public void backto_fitness(View view){
        Intent intent = new Intent(UbActivity.this,FitnessActivity.class);
        startActivity(intent);
    }
}