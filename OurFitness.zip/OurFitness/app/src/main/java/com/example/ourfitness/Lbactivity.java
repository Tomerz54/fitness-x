package com.example.ourfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Lbactivity extends AppCompatActivity {

    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lbactivity);


        newArray = new int[]{
                R.id.lunges_pose, R.id.glute_bridge_pose,
                R.id.lunge_twist_pose, R.id.wall_sit, R.id.bulgarian_split,
                R.id.squat_pose, R.id.side_squat,
                R.id.curtsy_lunges, R.id.butt_kicks, R.id.calve_raises


        };
    }

    public void image_onclicked(View view)
    {
        for (int i=0; i<newArray.length; i++)
        {
            if(view.getId() == newArray[i])
            {
                int value = i+1;
                Log.i("First",String.valueOf(value));
                Intent intent = new Intent(Lbactivity.this,Lb_time_view.class);
                intent.putExtra("value",String.valueOf(value));
                startActivity(intent);
            }
        }
    }

    public void backto_fitness(View view){
        Intent intent = new Intent(Lbactivity.this,FitnessActivity.class);
        startActivity(intent);
    }
}