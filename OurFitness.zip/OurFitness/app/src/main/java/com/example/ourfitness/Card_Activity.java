package com.example.ourfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Card_Activity extends AppCompatActivity {

    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        newArray = new int[]{
                R.id.jumping_jacks, R.id.plank_row_leg_raise,
                R.id.burpees, R.id.chest_fly_glute_bridge,
                R.id.flutter_kick_squats, R.id.v_sit_curl_press,
                R.id.skating_windmill,R.id.stutter_steps


        };
    }

    public void Ubimage_onclicked(View view)
    {
        for (int i=0; i<newArray.length; i++)
        {
            if(view.getId() == newArray[i])
            {
                int value = i+1;
                Log.i("First",String.valueOf(value));
                Intent intent = new Intent(Card_Activity.this,Cardio_time_view.class);
                intent.putExtra("value",String.valueOf(value));
                startActivity(intent);
            }
        }
    }

    public void backto_fitness(View view){
        Intent intent = new Intent(Card_Activity.this,FitnessActivity.class);
        startActivity(intent);
    }
}