package com.example.ourfitness;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;

import java.util.Locale;

public class Yoga_time_view extends AppCompatActivity {


    String button_value;

    private static final long START_TIME_IN_MILLIS= 60000;

    private long time_left_in_millis = START_TIME_IN_MILLIS;

    private boolean timerRunning;

    private CountDownTimer count_DownTimer;

    AppCompatButton timer;

    AppCompatButton reset;

    AppCompatButton start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yoga_time_view);

        Intent intent = getIntent();
        button_value = intent.getStringExtra("value");

        int int_value = Integer.parseInt(button_value);

        switch(int_value) {

            case 1:
                setContentView(R.layout.activity_easy_pose);
                break;
            case 2:
                setContentView(R.layout.activity_child_pose);
                break;
            case 3:
                setContentView(R.layout.activity_catcow);
                break;
            case 4:
                setContentView(R.layout.activity_downward_dog);
                break;
            case 5:
                setContentView(R.layout.activity_standing_forward_bend);
                break;
            case 6:
                setContentView(R.layout.activity_reciling_bound_angle);
                break;
            case 7:
                setContentView(R.layout.activity_bridge_pose);
                break;
            case 8:
                setContentView(R.layout.activity_cobra_pose);
                break;
            case 9:
                setContentView(R.layout.activity_legs_up_the_wall);
                break;


        }

        timer = (AppCompatButton) findViewById(R.id.timer);

        start = (AppCompatButton) findViewById(R.id.startbutton);

        reset = (AppCompatButton) findViewById(R.id.reset);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!timerRunning){
                    Start_Timer();
                }
                else {
                    Pause_Timer();
                }
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Reset_Timer();
            }
        });

        updateCountDownText();
    }

    private void Start_Timer(){

        count_DownTimer = new CountDownTimer(time_left_in_millis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Update the timer TextView with the remaining time


                time_left_in_millis = millisUntilFinished;
                updateCountDownText();

            }

            @Override
            public void onFinish() {
                // Handle timer finish event
                timerRunning = false;
                start.setVisibility(View.INVISIBLE);
                reset.setVisibility(View.VISIBLE);


            }
        }.start();

        timerRunning = true;
        start.setText("Pause");
        reset.setVisibility(View.INVISIBLE);

    }

    private void Pause_Timer(){
        count_DownTimer.cancel();
        timerRunning=false;
        start.setText("Start");
        reset.setVisibility(View.VISIBLE);
    }
    private void Reset_Timer(){
        time_left_in_millis = START_TIME_IN_MILLIS;
        reset.setVisibility(View.INVISIBLE);
        start.setVisibility(View.VISIBLE);
        updateCountDownText();

    }

    private void updateCountDownText() {
        int minutes = (int) (time_left_in_millis / 1000) / 60;
        int seconds = (int) (time_left_in_millis / 1000) % 60;

        String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);

        timer.setText(timeLeftFormatted);
    }

    public void ret_butt(View view){
        Intent intent = new Intent(Yoga_time_view.this,YogaActivity.class);
        startActivity(intent);
    }
}