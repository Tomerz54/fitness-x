package com.example.ourfitness

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatButton

class FitnessActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fitness)

        val backward_butt = findViewById<ImageButton>(R.id.back_butt)
        backward_butt.setOnClickListener{
            val Intention = Intent(this,MainActivity::class.java)
            startActivity(Intention)
        }



    }

    //scroller fitness activities:
    // -------------------------------------------------------------------------------------

    fun open_fbAct(view: View) {
        val fb_butt = findViewById<ImageView>(R.id.fb_img)
        fb_butt.setOnClickListener{
            val Intention = Intent(this,Fbactivity::class.java)
            startActivity(Intention)
        }
    }

    fun cardio_onclicked(view: View) {
        val c_butt = findViewById<ImageView>(R.id.cardio_button)
        c_butt.setOnClickListener{
            val Intention = Intent(this,Card_Activity::class.java)
            startActivity(Intention)
        }
    }

    fun yoga_onclicked(view: View) {
        val yg_butt = findViewById<ImageView>(R.id.yoga_button)
        yg_butt.setOnClickListener{
            val Intention = Intent(this,YogaActivity::class.java)
            startActivity(Intention)
        }
    }

    //Fitness activites bellow:
    // -------------------------------------------------------------------------------------

    fun open_lbAct(view: View) {
        val lb_button = findViewById<Button>(R.id.lb_button)
        lb_button.setOnClickListener{
            val Intention = Intent(this,Lbactivity::class.java)
            startActivity(Intention)
        }
    }

    fun open_ubAct(view: View) {
        val ub_button = findViewById<Button>(R.id.ub_button)
        ub_button.setOnClickListener{
            val Intention = Intent(this,UbActivity::class.java)
            startActivity(Intention)
        }
    }

    fun open_bAct(view: View) {
        val b_button = findViewById<Button>(R.id.b_button)
        b_button.setOnClickListener{
            val Intention = Intent(this,BActivity::class.java)
            startActivity(Intention)
        }
    }
}