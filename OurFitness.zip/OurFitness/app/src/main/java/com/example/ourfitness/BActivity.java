package com.example.ourfitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class BActivity extends AppCompatActivity {

    int[] newArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bactivity);

        newArray = new int[]{
                R.id.sit_ups_pose, R.id.jumping_rope,
                R.id.march_in_place, R.id.sprinter_crunches,
                R.id.russian_twists, R.id.bycicle_crunches,
                R.id.flutter_kicks


        };
    }

    public void image_onclicked(View view)
    {
        for (int i=0; i<newArray.length; i++)
        {
            if(view.getId() == newArray[i])
            {
                int value = i+1;
                Log.i("First",String.valueOf(value));
                Intent intent = new Intent(BActivity.this,belly_timer_view.class);
                intent.putExtra("value",String.valueOf(value));
                startActivity(intent);
            }
        }
    }

    public void backto_fitness(View view){
        Intent intent = new Intent(BActivity.this,FitnessActivity.class);
        startActivity(intent);
    }

}